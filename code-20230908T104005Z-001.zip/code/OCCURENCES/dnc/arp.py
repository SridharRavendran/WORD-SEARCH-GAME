from twisted.internet import reactor, protocol
from twisted.protocols.basic import NetstringReceiver

class ARPQueryProtocol(NetstringReceiver):
    def stringReceived(self, query_ip):
        print(f"Received ARP query for IP: {query_ip.decode()}")
        mac_address = self.factory.lookup_mac_address(query_ip.decode())
        if mac_address:
            self.sendString(mac_address.encode())

class ARPServerFactory(protocol.ServerFactory):
    protocol = ARPQueryProtocol

    def __init__(self, ip_mac_mappings):
        self.ip_mac_mappings = ip_mac_mappings

    def lookup_mac_address(self, ip_address):
        return self.ip_mac_mappings.get(ip_address)

def main():
    ip_mac_mappings = {
        "192.168.0.1": "00:11:22:33:44:55",
        "192.168.0.2": "AA:BB:CC:DD:EE:FF",
        # Add more IP-MAC mappings as needed
    }

    factory = ARPServerFactory(ip_mac_mappings)
    reactor.listenTCP(1234, factory)
    print("ARP server started.")
    reactor.run()

if __name__ == '__main__':
    main()
