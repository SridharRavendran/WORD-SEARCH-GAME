from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor

class ChatServer(DatagramProtocol):
    def __init__(self):
        self.clients = []

    def datagramReceived(self, datagram, address):
        message = datagram.decode()
        print(f"Received message: {message} from {address}")
        if message.lower()=='quit':
            self.transport.stopListening()
        self.broadcast(message, address)

    def broadcast(self, message, sender_address):
        if sender_address in self.clients:

            for client in self.clients:
                if client != sender_address:#new client
                    self.transport.write(message.encode(), client)

        else:
            self.clients.append(sender_address)
            print('welcome to the chat user:',sender_address)
def main():
    reactor.listenUDP(1236, ChatServer())
    print("Chat server started.")
    reactor.run()

if __name__ == '__main__':
    main()
