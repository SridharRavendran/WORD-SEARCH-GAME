from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor
import pickle
import time

class EchoUDP(DatagramProtocol):
    def datagramReceived(self, datagram, address):
        receive_time = time.time()  # Get the receive timestamp
        file_name, file_data, send_time = pickle.loads(datagram)
        print(f'{file_name} received!')
        line_count = file_data.count('\n')
        data = (file_name, line_count)
        self.transport.write(pickle.dumps(data), address)

def main():
    reactor.listenUDP(1298, EchoUDP())
    print("UDP server started.")
    reactor.run()

if __name__ == '__main__':
    main()
