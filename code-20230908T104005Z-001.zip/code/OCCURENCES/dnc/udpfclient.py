from __future__ import print_function
import pickle
import time
from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor

class EchoClientDatagramProtocol(DatagramProtocol):
    def startProtocol(self):
        self.transport.connect('127.0.0.1', 1298)
        self.sendDatagram()

    def sendDatagram(self):
        file_name = input('Enter file name to send: ')
        file = open(f'{file_name}', 'r')
        file_data = file.read()
        send_time = time.time()  # Get the send timestamp
        data = (file_name, file_data, send_time)
        if file_name:
            self.transport.write(pickle.dumps(data))
        else:
            reactor.stop()

    def datagramReceived(self, datagram, address):
        data = pickle.loads(datagram)
        file_name = data[0]
        line_count = data[1]
        print(f"File name: {file_name}")
        print(f"Number of lines: {line_count}")

def main():
    protocol = EchoClientDatagramProtocol()
    t = reactor.listenUDP(0, protocol)
    reactor.run()

if __name__ == '__main__':
    main()

