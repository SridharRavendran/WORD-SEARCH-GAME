from twisted.internet import reactor, protocol
from twisted.protocols.basic import NetstringReceiver

class ARPClientProtocol(NetstringReceiver):
    def connectionMade(self):
        query_ip = input("Enter the IP address to query: ")
        self.sendString(query_ip.encode())

    def stringReceived(self, mac_address):
        print(f"Received ARP reply. MAC address: {mac_address.decode()}")

class ARPClientFactory(protocol.ClientFactory):
    protocol = ARPClientProtocol

def main():
    reactor.connectTCP("localhost", 1234, ARPClientFactory())
    reactor.run()

if __name__ == '__main__':
    main()
