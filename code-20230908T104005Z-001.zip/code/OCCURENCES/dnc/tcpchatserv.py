from twisted.internet import reactor, protocol
from twisted.protocols import basic

class ChatProtocol(basic.LineReceiver):
    def __init__(self, factory):
        self.factory = factory

    def connectionMade(self):
        self.factory.clients.append(self)
        print("Client connected:", self.transport.getPeer().host)

    def connectionLost(self, reason):
        self.factory.clients.remove(self)
        print("Client disconnected:", self.transport.getPeer().host)

    def lineReceived(self, line):
        message = line.decode()
        print(f"Received message: {message} from {self.transport.getPeer().host}")
        self.factory.broadcast(message)

class ChatFactory(protocol.Factory):
    def __init__(self):
        self.clients = []

    def buildProtocol(self, addr):
        return ChatProtocol(self)

    def broadcast(self, message):
        for client in self.clients:
            client.sendLine(message.encode())

def main():
    reactor.listenTCP(8000, ChatFactory())
    print("Chat server started.")
    reactor.run()

if __name__ == '__main__':
    main()
