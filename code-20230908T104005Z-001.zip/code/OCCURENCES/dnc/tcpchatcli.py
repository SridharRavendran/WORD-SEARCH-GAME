from twisted.internet import reactor, protocol
from twisted.protocols import basic

class ChatProtocol(basic.LineReceiver):
    def lineReceived(self, line):
        message = line.decode()
        print(f"Received message: {message}")

class ChatClientFactory(protocol.ClientFactory):
    def startedConnecting(self, connector):
        print("Connecting to chat server...")

    def buildProtocol(self, addr):
        print("Connected to chat server.")
        return ChatProtocol()

    def clientConnectionFailed(self, connector, reason):
        print("Connection failed. Reason:", reason)
        reactor.stop()

    def clientConnectionLost(self, connector, reason):
        print("Connection lost. Reason:", reason)
        reactor.stop()

def main():
    reactor.connectTCP('localhost', 8000, ChatClientFactory())
    reactor.run()

if __name__ == '__main__':
    main()
