from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor

class ChatClient(DatagramProtocol):
    def startProtocol(self):
        self.transport.connect('127.0.0.1', 1236)
        while(True):
            a=input('enter message')
            self.sendMessage(a)     
        
    def datagramReceived(self, datagram, address):
        message = datagram.decode()
        print(f"Received message: {message}")

    def sendMessage(self, message):
        self.transport.write(message.encode())
        

def main():
    client = ChatClient()
    reactor.listenUDP(0, client)
    reactor.run()

if __name__ == '__main__':
    main()
