from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor
class EchoUDP(DatagramProtocol):
    def datagramReceived(self, datagram, address):
        print("Datagram: ",datagram.decode())
        self.transport.write(datagram, address)#!!!mention addr
def main():
    reactor.listenUDP(8000, EchoUDP())
    print("Started to listen")
    reactor.run()
if __name__ == '__main__':
    main()
