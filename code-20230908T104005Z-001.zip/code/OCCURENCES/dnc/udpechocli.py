from twisted.internet.protocol import DatagramProtocol
from twisted.internet import reactor
import time
class EchoClientDatagramProtocol(DatagramProtocol):
    a = input("Enter the message: ")
    strings = [f"{a}".encode()]
    def startProtocol(self):
        self.transport.connect('127.0.0.1', 8000)
        self.sendDatagram()
        
    def sendDatagram(self):
        if len(self.strings):
            datagram = self.strings.pop(0)
            self.timestamp = time.time()
            self.transport.write(datagram)
        else:
            reactor.stop()
    def datagramReceived(self, datagram, host):
        rtt = time.time() - self.timestamp
        print('Datagram received: ', datagram.decode(), f"< RTT: {rtt:.4f}s >")
        
def main():
    protocol = EchoClientDatagramProtocol()
    t = reactor.listenUDP(0, protocol)
    reactor.run()
if __name__ == '__main__':
    main()