# Helper function to find the blank (empty) tile in the puzzle
def find_blank(puzzle):
    for row in range(3):
        for col in range(3):
            if puzzle[row][col] == 0:
                return row, col

# Helper function to check if a given puzzle state is the goal state
def is_goal(puzzle, goal):
    return puzzle == goal

# Helper function to perform the swap operation on the puzzle
def swap(puzzle, row1, col1, row2, col2):
    puzzle[row1][col1], puzzle[row2][col2] = puzzle[row2][col2], puzzle[row1][col1]

# Helper function to print the puzzle state
def print_puzzle(puzzle):
    for row in puzzle:
        print(row)
    print()

# Function to perform the depth-limited search
def dls(puzzle, goal, depth_limit):
    if is_goal(puzzle, goal):
        return True

    if depth_limit == 0:
        return False

    blank_row, blank_col = find_blank(puzzle)

    # Move the blank tile in all possible directions (up, down, left, right)
    for row, col in [(blank_row-1, blank_col), (blank_row+1, blank_col), (blank_row, blank_col-1), (blank_row, blank_col+1)]:
        if 0 <= row < 3 and 0 <= col < 3:
            swap(puzzle, blank_row, blank_col, row, col)
            if dls(puzzle, goal, depth_limit - 1):
                return True
            swap(puzzle, blank_row, blank_col, row, col)

    return False

# Function to perform the Iterative Deepening Search (IDS)
def ids(puzzle, goal):
    depth_limit = 0

    while True:
        if dls(puzzle, goal, depth_limit):
            return depth_limit
        depth_limit += 1

# Example usage
start_state = [[1, 2, 3],
               [0, 4, 6],
               [7, 5, 8]]

goal_state = [[1, 2, 3],
              [4, 5, 6],
              [7, 8, 0]]

print("Start State:")
print_puzzle(start_state)

print("Goal State:")
print_puzzle(goal_state)

num_moves = ids(start_state, goal_state)

if num_moves is not None:
    print("Solution found!")
    print("Minimum number of moves:", num_moves)
else:
    print("No solution exists.")
