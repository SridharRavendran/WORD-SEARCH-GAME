def tsp_nearest_neighbor(graph, start_vertex=0):
    num_vertices = len(graph)
    visited = [False] * num_vertices
    path = [start_vertex]
    visited[start_vertex] = True

    for _ in range(num_vertices - 1):
        current_vertex = path[-1]
        next_vertex = None
        min_distance = float('inf')

        for neighbor in range(num_vertices):
            if not visited[neighbor] and graph[current_vertex][neighbor] < min_distance:
                next_vertex = neighbor
                min_distance = graph[current_vertex][neighbor]

        path.append(next_vertex)
        visited[next_vertex] = True

    path.append(start_vertex)
    total_distance = sum(graph[path[i]][path[i+1]] for i in range(num_vertices))

    return total_distance, path

# Example usage
graph = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]

total_distance, path = tsp_nearest_neighbor(graph)

print("Total Distance:", total_distance)
print("Path:", path)
