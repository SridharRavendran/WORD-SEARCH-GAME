
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None



def inorder(root):
    if root is not None:

        inorder(root.left)
        print(str(root.key), end=' ')
        inorder(root.right)



def insert(node, key):


    if node is None:
        return Node(key)
    if key < node.key:
        node.left = insert(node.left, key)
    else:
        node.right = insert(node.right, key)

    return node



def minValueNode(node):
    current = node
    while (current.left is not None):
        current = current.left

    return current


def search(root, val):
    if (root is None):
        return 'Not found'
    elif (root.key == val):
        return 'Found'
    elif (root.key < val):
        return search(root.right, val)
    return search(root.left, val)



def deleteNode(root, key):

    if root is None:
        return root


    if key < root.key:
        root.left = deleteNode(root.left, key)
    elif (key > root.key):
        root.right = deleteNode(root.right, key)
    else:
        # If the node is with only one child or no child
        if root.left is None:
            temp = root.right
            root = None
            return temp

        elif root.right is None:
            temp = root.left
            root = None
            return temp

        # If the node has two children,
        # place the inorder successor in position of the node to be deleted
        temp = minValueNode(root.right)

        root.key = temp.key

        # Delete the inorder successor
        root.right = deleteNode(root.right, temp.key)

    return root


root = None
root = insert(root, 8)
root = insert(root, 3)
root = insert(root, 1)
root = insert(root, 6)
root = insert(root, 7)
root = insert(root, 10)
root = insert(root, 14)
root = insert(root, 4)

print("Inorder traversal: ", end=' ')
inorder(root)

print("\nDelete 10")
root = deleteNode(root, 10)
print("Inorder traversal: ", end=' ')
inorder(root)

root = None
flag = True

while flag:

    print('MENU')

    print('''
    1. Insert node
    2. Search Node
    3. Delete Node
    4. Display Tree
    5. Quit
    ''')
    x = int(input('Enter choice:'))

    if x == 1:
        n = int(input('Enter no. of nodes to be inserted:'))
        for i in range(n):
            key = int(input('Enter value'))
            root = insert(root, key)
        print("Inorder Traversal after insertion -")
        inorder(root)
        print()

    elif x == 2:
        h = int(input('Enter key of node to be searched:'))
        print(search(root, h))

    elif x == 3:
        d = int(input('enter key of node to be deleted:'))
        root = deleteNode(root, d)
        print("Inorder Traversal after deletion -")
        inorder(root)
        print()

    elif x == 4:
        print("Inorder Traversal -")
        inorder(root)
        print()

    elif x == 5:
        flag = False
