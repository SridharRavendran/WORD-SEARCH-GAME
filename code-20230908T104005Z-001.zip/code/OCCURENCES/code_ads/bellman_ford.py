class Graph:
    def __init__(self, num_vertices):
        self.num_vertices = num_vertices
        self.edges = []

    def add_edge(self, src, dest, weight):
        self.edges.append((src, dest, weight))

    def bellman_ford(self, source):
        distances = [float('inf')] * self.num_vertices
        distances[source] = 0

        for _ in range(self.num_vertices - 1):
            for src, dest, weight in self.edges:
                if distances[src] != float('inf') and distances[src] + weight < distances[dest]:
                    distances[dest] = distances[src] + weight

        #Check for negative-weight cycles
        for src, dest, weight in self.edges:
            if distances[src] != float('inf') and distances[src] + weight < distances[dest]:
                print("Graph contains negative-weight cycle")
                return

        return distances

# Example usage
g = Graph(5)
g.add_edge(0, 1, 6)
g.add_edge(0, 3, 7)
g.add_edge(1, 2, 5)
g.add_edge(1, 3, 8)
g.add_edge(1, 4, -4)
g.add_edge(2, 1, -2)
g.add_edge(3, 2, -3)
g.add_edge(3, 4, 9)
g.add_edge(4, 0, 2)
g.add_edge(4, 2, 7)

source_vertex = 0
shortest_distances = g.bellman_ford(source_vertex)

print("Shortest distances from source vertex", source_vertex, "to all other vertices:")
for i, distance in enumerate(shortest_distances):
    print("Vertex", i, ":", distance)
