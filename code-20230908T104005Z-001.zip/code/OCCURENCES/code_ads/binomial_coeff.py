def binomial_coefficient(n, k):
    table = [[0] * (k + 1) for _ in range(n + 1)] #no of rows: n+1, no of columns : k+1
    
    for i in range(n + 1):
        for j in range(min(i, k) + 1):
            if j == 0 or j == i:
                table[i][j] = 1
            else:
                table[i][j] = table[i - 1][j - 1] + table[i - 1][j]
    return table[n][k]
# Driver Code
n = int(input("\nEnter the value for n: "))
k = int(input("\nEnter the value for k: "))
result = binomial_coefficient(n, k)
print(f"\nThe binomial coefficient C({n}, {k}) is: {result}")
