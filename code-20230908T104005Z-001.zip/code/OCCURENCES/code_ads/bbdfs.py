import sys

class TSPSolver:
    def __init__(self, graph):
        self.graph = graph
        self.num_nodes = len(graph)
        self.best_path = []
        self.best_cost = sys.maxsize
        self.visited = [False] * self.num_nodes

    def tsp(self):
        start_node = 0  # Start from node 0
        path = [start_node]
        current_cost = 0
        self.visited[start_node] = True
        self._dfs(start_node, path, current_cost)

        return self.best_path, self.best_cost

    def _dfs(self, node, path, current_cost):
        if len(path) == self.num_nodes:
            # Visited all nodes, check if it forms a better path
            current_cost += self.graph[node][path[0]]
            if current_cost < self.best_cost:
                self.best_cost = current_cost
                self.best_path = path + [path[0]]#!!!!!!
            return

        for next_node in range(self.num_nodes):
            if not self.visited[next_node] and self.graph[node][next_node] != 0:
                self.visited[next_node] = True
                self._dfs(next_node, path + [next_node], current_cost + self.graph[node][next_node])
                self.visited[next_node] = False

graph = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]

solver = TSPSolver(graph)
best_path, best_cost = solver.tsp()

print("Best Path:", best_path)
print("Best Cost:", best_cost)