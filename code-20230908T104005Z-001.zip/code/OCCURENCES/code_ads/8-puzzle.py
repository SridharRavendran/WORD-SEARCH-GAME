from collections import deque

# Function to swap two tiles in the puzzle
def swap_tiles(puzzle, i, j, new_i, new_j):
    puzzle[i][j], puzzle[new_i][new_j] = puzzle[new_i][new_j], puzzle[i][j]

# Function to check if the puzzle is solved
def is_solved(puzzle):
    goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
    return puzzle == goal_state

# Function to get the possible neighbors of the current puzzle state
def get_neighbors(puzzle):
    neighbors = []
    for i in range(3):
        for j in range(3):
            if puzzle[i][j] == 0:
                if i > 0:
                    new_puzzle = [row[:] for row in puzzle]  # Create a copy of the puzzle
                    swap_tiles(new_puzzle, i, j, i - 1, j)  # Swap the empty tile with the one above it
                    neighbors.append(new_puzzle)
                if i < 2:
                    new_puzzle = [row[:] for row in puzzle]
                    swap_tiles(new_puzzle, i, j, i + 1, j)  # Swap the empty tile with the one below it
                    neighbors.append(new_puzzle)
                if j > 0:
                    new_puzzle = [row[:] for row in puzzle]
                    swap_tiles(new_puzzle, i, j, i, j - 1)  # Swap the empty tile with the one to the left
                    neighbors.append(new_puzzle)
                if j < 2:
                    new_puzzle = [row[:] for row in puzzle]
                    swap_tiles(new_puzzle, i, j, i, j + 1)  # Swap the empty tile with the one to the right
                    neighbors.append(new_puzzle)
    return neighbors

# Depth-First Search
def dfs(puzzle):
    stack = deque([(puzzle, [])])  # Stack to keep track of puzzle states and their corresponding paths
    visited = set()

    while stack:
        current_state, path = stack.pop()

        if is_solved(current_state):
            return path

        visited.add(tuple(map(tuple, current_state)))

        for neighbor in get_neighbors(current_state):
            if tuple(map(tuple, neighbor)) not in visited:
                stack.append((neighbor, path + [neighbor]))

    return None  # Return None if no solution is found

# Example usage
puzzle = [[1, 2, 3], [4, 5, 6], [0, 7, 8]]
solution = dfs(puzzle)

if solution:
    print("Solution found!")
    for step in solution:
        print(step)
else:
    print("No solution found.")
