def is_valid(vertex, graph, path, pos):
    # Check if the vertex can be added to the path
    if graph[path[pos-1]][vertex] == 0:
        return False

    # Check if the vertex has already been visited
    if vertex in path:
        return False

    return True

def hamiltonian_circuit_util(graph, path, pos):
    num_vertices = len(graph)

    if pos == num_vertices:
        # Check if the last vertex is connected to the starting vertex
        if graph[path[pos-1]][path[0]] == 1:
            return True
        return False

    for vertex in range(1, num_vertices):
        if is_valid(vertex, graph, path, pos):
            path[pos] = vertex

            if hamiltonian_circuit_util(graph, path, pos+1):
                return True

            # Backtrack
            path[pos] = -1

    return False

def hamiltonian_circuit(graph):
    num_vertices = len(graph)
    path = [-1] * num_vertices

    # Start with the first vertex as the starting point
    path[0] = 0

    if hamiltonian_circuit_util(graph, path, 1):
        return path

    return None

# Example usage
graph = [
    [0, 1, 0, 1, 0],
    [1, 0, 1, 1, 1],
    [0, 1, 0, 0, 1],
    [1, 1, 0, 0, 1],
    [0, 1, 1, 1, 0]
]

result = hamiltonian_circuit(graph)

if result:
    print("Hamiltonian Circuit:", result)
else:
    print("No Hamiltonian Circuit exists.")
