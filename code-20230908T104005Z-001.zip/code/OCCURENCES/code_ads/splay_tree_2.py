class Node:
    def __init__(self, data):
        self.data = data
        self.parent = None
        self.left = None
        self.right = None


class SplayTree:
    def __init__(self):
        self.root = None

    def search_tree_helper(self, node, key):
        if node == None or key == node.data:
            return node

        if key < node.data:
            return self.search_tree_helper(node.left, key)
        return self.search_tree_helper(node.right, key)

    def delete_node_helper(self, node, key):
        x = None
        t = None
        s = None
        while node != None:
            if node.data == key:
                x = node

            if node.data <= key:
                node = node.right
            else:
                node = node.left

        if x == None:
            print("Couldn't find key in the tree")
            return

        # split operation
        self.__splay(x)
        if x.right != None:
            t = x.right
            t.parent = None
        else:
            t = None

        s = x
        s.right = None
        x = None

        # join operation
        if s.left != None:
            s.left.parent = None

        self.root = self.__join(s.left, t)
        s = None


    def __left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != None:
            y.left.parent = x

        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y


    def __right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != None:
            y.right.parent = x

        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y

        y.right = x
        x.parent = y

    def __splay(self, x):
        while x.parent != None:
            if x.parent.parent == None:
                if x == x.parent.left:
                    # zig rotation
                    self.__right_rotate(x.parent)
                else:
                    # zag rotation
                    self.__left_rotate(x.parent)
            elif x == x.parent.left and x.parent == x.parent.parent.left:
                # zig-zig rotation
                self.__right_rotate(x.parent.parent)
                self.__right_rotate(x.parent)
            elif x == x.parent.right and x.parent == x.parent.parent.right:
                # zag-zag rotation
                self.__left_rotate(x.parent.parent)
                self.__left_rotate(x.parent)
            elif x == x.parent.right and x.parent == x.parent.parent.left:
                # zig-zag rotation
                self.__left_rotate(x.parent)
                self.__right_rotate(x.parent)
            else:
                # zag-zig rotation
                self.__right_rotate(x.parent)
                self.__left_rotate(x.parent)


    def __join(self, s, t):
        if s == None:
            return t

        if t == None:
            return s

        x = self.maximum(s)
        self.__splay(x)
        x.right = t
        t.parent = x
        return x

    def inOrder(self, n):
        if n != None:
            self.inOrder(n.left)
            print(n.data)
            self.inOrder(n.right)

    def splaySearch(self, n, x):
        while (n != None):
            if x == n.data:
                self.__splay(n)
                return ('found')
            elif x < n.data:
                return self.splaySearch(n.left, x)
            elif x > n.data:
                return self.splaySearch(n.right, x)
        return ('not found')

    def insert(self, key):
        node = Node(key)
        y = None
        x = self.root

        while x != None:
            y = x
            if node.data < x.data:
                x = x.left
            else:
                x = x.right


        node.parent = y
        if y == None:
            self.root = node
        elif node.data < y.data:
            y.left = node
        else:
            y.right = node

        self.__splay(node)


    def delete_node(self, data):
        self.delete_node_helper(self.root, data)


    def maximum(self, node):
        while node.right != None:
            node = node.right
        return node
#MENU


Tree = SplayTree()
root = None
flag = True

while (flag):

    print('MENU')

    print('''
    1. Insert node
    2. Search Node
    3. Delete Node
    4. Display Tree
    5. Quit
    ''')
    x = int(input('Enter choice:'))

    if x == 1:
        n = int(input('Enter no. of nodes to be inserted:'))
        for i in range(n):
            key = int(input('Enter value:'))
            root = Tree.insert(key)
        print("Inorder Traversal after insertion -")
        Tree.inOrder(Tree.root)
        print()

    elif x == 2:
        h = int(input('Enter key of node to be searched:'))
        print(Tree.splaySearch(Tree.root, h))
        print()

    elif x == 3:
        d = int(input('enter key of node to be deleted:'))
        root = Tree.delete_node(d)
        print("Inorder Traversal after deletion -")
        Tree.inOrder(Tree.root)
        print()

    elif x == 4:
        print("Inorder Traversal -")
        Tree.inOrder(Tree.root)

    elif x == 5:
        flag = False
