from collections import defaultdict

class Graph:
	def __init__(self):

		self.graph = defaultdict(list) #adjacenecy list structure 


	def addEdge(self, u, v):
		self.graph[u].append(v)
 

	def BFS(self,s,g):
            visited={}
            queue = []
            route=[]
            queue.append(s)
            visited[s] = True
            while queue:
                s = queue.pop(0)
                route.append(s)
                if s == g:
                    return route
                for i in self.graph[s]:
                    if i not in visited:
                        queue.append(i)
                        visited[i] = True
            else:
                return False


# Driver code
if __name__ == '__main__':
    n=int(input("Enter number of edges to be inserted:"))
    g = Graph()
    for _ in range(n):
        source_vertex=input("Enter the source vertex:")
        dest_vertex=input("Enter the detination vertex:")
        g.addEdge(source_vertex,dest_vertex)
    start_vertex=input("Enter the starting vertex:")
    goal_vertex=input("Enter the goal vertex:")
    res=g.BFS(start_vertex,goal_vertex) 
    if res is False:
        print("Goal state not found in graph")
    else:
        print(res)




    



