class Item:
    def __init__(self, weight, value):
        self.weight = weight
        self.value = value
        self.cost = value / weight

def solve_knapsack(items, capacity):
    items.sort(key=lambda x: x.cost, reverse=True)
    best_value = 0
    best_solution = []

    def branch_and_bound(node, current_weight, current_value):
        nonlocal best_value, best_solution

        if current_weight > capacity:
            return

        if node == len(items):
            if current_value > best_value:
                best_value = current_value
                best_solution = [(item.weight, item.value) for item in items if item.weight <= current_weight]
            return

        item = items[node]

        if current_weight + item.weight <= capacity:
            branch_and_bound(node + 1, current_weight + item.weight, current_value + item.value)

        potential_value = current_value + (capacity - current_weight) * item.cost
        if potential_value > best_value:
            branch_and_bound(node + 1, current_weight, current_value)

    branch_and_bound(0, 0, 0)#!!!
    return best_value, best_solution

# Example usage
items = [
    Item(2, 10),
    Item(5, 25),
    Item(10, 15),
    Item(6, 30),
    Item(4, 40)
]

capacity = 16
max_value, solution = solve_knapsack(items, capacity)

print("Max Value:", max_value)
print("Items in Knapsack:")
for weight, value in solution:
    print("Weight:", weight, "Value:", value)

