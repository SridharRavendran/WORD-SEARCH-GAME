
from collections import defaultdict
class Graph:
    def __init__(self):
        self.graph = defaultdict(list) #adjacency list strcuture
    def addEdge(self, u, v):
        self.graph[u].append(v)
    def DFSUtil(self, v, visited,goal_vertex, route):
        visited.add(v)
        route.append(v)
        if v == goal_vertex:
            return route              

        for neighbour in self.graph[v]:
            if neighbour not in visited:
                if self.DFSUtil(neighbour, visited,goal_vertex, route) is not None:
                    return route
        route.pop()
        return None

    def DFS(self, v,goal_vertex,route=[]):
        visited = set()

        self.DFSUtil(v, visited,goal_vertex,route)
        if len(route) == 0:
            return False
        return route

# Driver code
if __name__ == '__main__':
    n=int(input("Enter number of edges to be inserted:"))
    g = Graph()
    for _ in range(n):
        source_vertex=input("Enter the source vertex:")
        dest_vertex=input("Enter the detination vertex:")
        g.addEdge(source_vertex,dest_vertex)
    start_vertex=input("Enter the starting vertex:")
    goal_vertex=input("Enter the goal vertex:")
    res=g.DFS(start_vertex,goal_vertex) 
    if res is False:
        print("Goal state not found in graph")
    else:
        print(res)