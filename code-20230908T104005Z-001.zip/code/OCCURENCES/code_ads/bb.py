import sys
from queue import Queue

class TSPSolver:
    def __init__(self, graph):
        self.graph = graph
        self.num_nodes = len(graph)
        self.best_path = []
        self.best_cost = sys.maxsize

    def tsp(self):
        queue = Queue()
        start_node = 0  # Start from node 0
        queue.put((start_node, [start_node], 0, {start_node}))

        while not queue.empty():
            node, path, current_cost, visited = queue.get()

            if len(path) == self.num_nodes:
                # Visited all nodes, check if it forms a better path
                current_cost += self.graph[node][start_node]
                if current_cost < self.best_cost:
                    self.best_cost = current_cost
                    self.best_path = path + [start_node]
                continue

            for next_node in range(self.num_nodes):
                if next_node not in visited and self.graph[node][next_node] != 0:
                    new_path = path + [next_node]
                    new_cost = current_cost + self.graph[node][next_node]
                    new_visited = visited.copy()
                    new_visited.add(next_node)
                    queue.put((next_node, new_path, new_cost, new_visited))

        return self.best_path, self.best_cost



graph = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]

solver = TSPSolver(graph)
best_path, best_cost = solver.tsp()

print("Best Path:", best_path)
print("Best Cost:", best_cost)
