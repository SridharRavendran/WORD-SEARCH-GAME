class DisjointSet:
    def __init__(self, vertices):
        self.parent = {}
        self.rank = {}
        for v in vertices:
            self.parent[v] = v
            self.rank[v] = 0

    def find(self, v):
        if self.parent[v] != v:
            self.parent[v] = self.find(self.parent[v])
        return self.parent[v]

    def union(self, v1, v2):
        root1 = self.find(v1)
        root2 = self.find(v2)
        if root1 != root2:
            if self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            elif self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
                self.parent[root1] = root2
                self.rank[root2] += 1


class Graph:
    def __init__(self, vertices):
        self.vertices = vertices
        self.graph = []

    def add_edge(self, src, dest, weight):
        self.graph.append((src, dest, weight))

    def kruskal(self):
        mst = []
        # Sort edges in ascending order of weight
        self.graph.sort(key=lambda x: x[2])
        disjoint_set = DisjointSet(self.vertices)
        for edge in self.graph:
            src, dest, weight = edge
            root1 = disjoint_set.find(src)
            root2 = disjoint_set.find(dest)
            if root1 != root2:
                mst.append(edge)
                disjoint_set.union(root1, root2)
        return mst


# Drive Code
vertices = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
g = Graph(vertices)
g.add_edge('A', 'B', 7)

g.add_edge('A', 'D', 5)
g.add_edge('B', 'C', 8)
g.add_edge('B', 'D', 9)
g.add_edge('B', 'E', 7)
g.add_edge('C', 'E', 5)
g.add_edge('D', 'E', 15)
g.add_edge('D', 'F', 6)
g.add_edge('E', 'F', 8)
g.add_edge('E', 'G', 9)
g.add_edge('F', 'G', 11)

minimum_spanning_tree = g.kruskal()
print("Minimum Spanning Tree:")
for edge in minimum_spanning_tree:
    print(edge[0], "--", edge[1], ":", edge[2])
