from heapq import heappush, heappop, heapify
from collections import defaultdict

class HuffmanNode:
    def __init__(self, char, frequency):
        self.char = char
        self.frequency = frequency
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.frequency < other.frequency

def build_frequency_table(data):
    frequency_table = defaultdict(int)
    for char in data:
        frequency_table[char] += 1
    return frequency_table

def build_huffman_tree(frequency_table):
    priority_queue = []
    for char, frequency in frequency_table.items():
        node = HuffmanNode(char, frequency)
        heappush(priority_queue, node)

    while len(priority_queue) > 1:
        left_node = heappop(priority_queue)
        right_node = heappop(priority_queue)
        sum_frequency = left_node.frequency + right_node.frequency
        parent_node = HuffmanNode(None, sum_frequency)
        parent_node.left = left_node
        parent_node.right = right_node
        heappush(priority_queue, parent_node)

    return priority_queue[0]

def build_huffman_codes(node, current_code, huffman_codes):
    if node is None:
        return

    if node.char:
        huffman_codes[node.char] = current_code

    build_huffman_codes(node.left, current_code + '0', huffman_codes)
    build_huffman_codes(node.right, current_code + '1', huffman_codes)

def huffman_encoding(data):
    frequency_table = build_frequency_table(data)
    huffman_tree = build_huffman_tree(frequency_table)
    huffman_codes = {}
    build_huffman_codes(huffman_tree, '', huffman_codes)
    print(huffman_codes)
    encoded_data = ''.join(huffman_codes[char] for char in data)
    return encoded_data, huffman_tree

def huffman_decoding(encoded_data, huffman_tree):
    decoded_data = ''
    current_node = huffman_tree

    for bit in encoded_data:
        if bit == '0':
            current_node = current_node.left
        else:
            current_node = current_node.right

        if current_node.char:
            decoded_data += current_node.char
            current_node = huffman_tree

    return decoded_data

# Example usage bbbbnnn  
data = "Hello, World!"
encoded_data, huffman_tree = huffman_encoding(data)
print("Encoded data:", encoded_data)
decoded_data = huffman_decoding(encoded_data, huffman_tree)
print("Decoded data:", decoded_data)
