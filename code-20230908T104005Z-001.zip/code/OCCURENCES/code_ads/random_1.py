import random
import math

# Function to calculate the total distance of a path
def calculate_distance(path, adjacency_matrix):
    total_distance = 0
    for i in range(len(path) - 1):
        city1 = path[i]
        city2 = path[i + 1]
        total_distance += adjacency_matrix[city1][city2]
    return total_distance

# Randomized TSP algorithm with adjacent swapping
def randomized_tsp(adjacency_matrix):
    num_cities = len(adjacency_matrix)
    cities = list(range(num_cities))

    # Initialize the current best distance and path
    best_distance = float('inf')
    best_path = []

    # Perform multiple iterations
    for _ in range(1000):
        # Randomly shuffle the cities
        random.shuffle(cities)

        # Randomly swap adjacent cities to find new routes
        for _ in range(num_cities):
            i = random.randint(0, num_cities - 2)
            cities[i], cities[i + 1] = cities[i + 1], cities[i]

        # Calculate the total distance for the shuffled path
        total_distance = calculate_distance(cities, adjacency_matrix)

        # Check if the current path is the best
        if total_distance < best_distance:
            best_distance = total_distance
            best_path = cities[:]

    return best_path, best_distance

# Example usage
adjacency_matrix = [
    [0, 3, 2, 4, 1],
    [3, 0, 1, 2, 3],
    [2, 1, 0, 2, 3],
    [4, 2, 2, 0, 1],
    [1, 3, 3, 1, 0]
]
best_path, best_distance = randomized_tsp(adjacency_matrix)

print("Best Path:", best_path)
print("Best Distance:", best_distance)
