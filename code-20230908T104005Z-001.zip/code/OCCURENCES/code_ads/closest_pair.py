import math


def distance(p1, p2):
    """Calculate the Euclidean distance between two points."""
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)


def closest_pair(points):
    # Sort points by x-coordinate
    points.sort(key=lambda p: p[0])

    def divide_and_conquer(points):
        n = len(points)

        # Base case: if there are only two points, return them as the closest pair
        if n == 2:
            return points[0], points[1]

        # Base case: if there are three points, return the closest pair among them
        if n == 3:
            d1 = distance(points[0], points[1])
            d2 = distance(points[0], points[2])
            d3 = distance(points[1], points[2])
            if d1 <= d2 and d1 <= d3:
                return points[0], points[1] #returns as tuple
            elif d2 <= d1 and d2 <= d3:
                return points[0], points[2]
            else:
                return points[1], points[2]

        # Divide the points into left and right halves
        mid = n // 2
        left_points = points[:mid]
        right_points = points[mid:]

        # Recursively find the closest pair in each half
        left_closest = divide_and_conquer(left_points)
        right_closest = divide_and_conquer(right_points)

        # Determine the minimum distance and the corresponding pair
        left_distance = distance(left_closest[0], left_closest[1])
        right_distance = distance(right_closest[0], right_closest[1])
        min_distance = min(left_distance, right_distance)
        min_pair = left_closest if left_distance == min_distance else right_closest

        # Find the closest pair that spans the two halves
        mid_x = points[mid][0]
        strip = [point for point in points if abs(point[0] - mid_x) < min_distance]
        strip.sort(key=lambda p: p[1]) # sort according to y coordinate

        for i in range(len(strip)):#outer loop
            j = i + 1
            while j < len(strip) and strip[j][1] - strip[i][1] < min_distance:  
                d = distance(strip[i], strip[j])
                if d < min_distance:
                    min_distance = d
                    min_pair = strip[i], strip[j]
                j += 1

        return min_pair

    return divide_and_conquer(points)


# Drive Code
points = [(2, 3), (12, 30), (40, 50), (5, 1), (12, 10), (3, 4)]
print("\nThe avaliable points are ", points)
closest_pair = closest_pair(points)
print("\nClosest pair:", closest_pair)
