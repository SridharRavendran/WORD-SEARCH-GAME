def isSafe(board, row, col):
    # Check if there is a queen in the same column
    for i in range(row):
        if board[i] == col:
            return False

    # Check if there is a queen in the same diagonal (top-left to bottom-right)
    i, j = row - 1, col - 1
    while i >= 0 and j >= 0:
        if board[i] == j:
            return False
        i -= 1
        j -= 1

    # Check if there is a queen in the same diagonal (top-right to bottom-left)
    i, j = row - 1, col + 1
    while i >= 0 and j < 4:
        if board[i] == j:
            return False
        i -= 1
        j += 1

    return True

def solveNQueens():
    board = [-1] * 4  # Initialize the board with -1 for empty positions

    # User input for queen positions
    for i in range(4):
        row, col = input("Enter the position of queen " + str(i + 1) + " (row, column): ").split()
        row = int(row)
        col = int(col)

        # Check if the position is within the board size
        if row < 0 or row >= 4 or col < 0 or col >= 4:
            print("Invalid position. Please enter valid positions.")
            return

        board[row] = col

    # Check if the given positions are safe
    for i in range(4):
        if not isSafe(board, i, board[i]):
            print("The given positions are not safe.")
            return

    print("The given positions are safe.")

# Call the solveNQueens function
solveNQueens()
