class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.parent=None

class SplayTree:
    def __init__(self):
        self.root = None

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left:
            y.left.parent = x
        y.parent = x.parent
        if not x.parent:
            self.root = y
        elif x == x.parent.left:#if x was left child of parennt
            x.parent.left = y
        else:
            x.parent.right = y#if x was right child of parent
        y.left = x  
        x.parent = y



    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right:
            y.right.parent = x
        y.parent = x.parent
        if not x.parent:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def splay(self, x):
        while x.parent:
            if not x.parent.parent:
                if x == x.parent.left: #if x is a left child of parent 
                    self.right_rotate(x.parent)
                else:
                    self.left_rotate(x.parent)
            elif x == x.parent.left and x.parent == x.parent.parent.left:
                self.right_rotate(x.parent.parent)
                self.right_rotate(x.parent)
            elif x == x.parent.right and x.parent == x.parent.parent.right:
                self.left_rotate(x.parent.parent)
                self.left_rotate(x.parent)
            elif x == x.parent.right and x.parent == x.parent.parent.left:
                self.left_rotate(x.parent)
                self.right_rotate(x.parent)#after left rotate x.parent is old x's grandparent
            else:
                self.right_rotate(x.parent)
                self.left_rotate(x.parent)

    def search(self, key):
        node = self.search_helper(self.root, key)
        if node:
            self.splay(node)
            return node.key
        else:
            return None

    def search_helper(self, node, key):
        if not node or node.key == key:
            return node
        if key < node.key:
            return self.search_helper(node.left, key)
        return self.search_helper(node.right, key)

    def insert(self, key):
        node = Node(key)
        if not self.root:
            self.root = node
        else:
            current = self.root
            while True:
                if key < current.key:
                    if current.left:
                        current = current.left
                    else:
                        current.left = node
                        node.parent = current
                        break
                else:
                    if current.right:
                        current = current.right
                    else:
                        current.right = node
                        node.parent = current
                        break
        self.splay(node)

    def delete(self, key):
        node = self.search_helper(self.root, key)
        if not node:
            return
        self.splay(node) #makes node the root
        if not node.left: # if there are only two nodes in tree
            self.root = node.right
            if self.root:
                self.root.parent = None
        elif not node.right: # if there only two nodes in tree
            self.root = node.left
            if self.left:
                self.root.parent = None
        else:
            left_subtree = node.left
            right_subtree = node.right
            self.root = left_subtree
            left_subtree.parent = None
            x = self.maximum(left_subtree)
            self.splay(x)
            self.root.right = right_subtree
            right_subtree.parent = self.root

    def in_order(self, node):
        if node:
            print(node.key, end=' ')
            self.in_order(node.left)
            
            self.in_order(node.right)

    def maximum(self, node):
        while node.right:
            node = node.right
        return node


# Example usage
tree = SplayTree()

tree.insert(5)
tree.insert(3)
tree.insert(7)
tree.insert(1)
tree.insert(4)

print("Inorder Traversal:")
tree.in_order(tree.root)
print()

print("Search 3:", tree.search(3))
print("Search 6:", tree.search(6))
tree.in_order(tree.root)

tree.delete(3)
print("Inorder Traversal after deletion:")
tree.in_order(tree.root)