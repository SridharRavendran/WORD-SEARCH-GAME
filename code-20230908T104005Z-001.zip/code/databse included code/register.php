<?php
// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirm-password'];

// Validate form data
$errors = [];

try {
    if (empty($name)) {
        $errors[] = "Name is required.";
    }

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($username)) {
        $errors[] = "Username is required.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // If there are validation errors, display them
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p>$error</p>";
        }
    } else {
        // If there are no errors, store user details in the database
        $servername = "localhost";
        $username1 = "root";
        $password1 = "";
        $dbname = "word_search";

        // Create a new PDO connection
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username1, $password1);

        // Prepare the SQL statement to check for existing username
        $stmt = $conn->prepare("SELECT * FROM registered_users WHERE username = ?");
        $stmt->execute([$username]);

        $existingUser = $stmt->fetch();

        if ($existingUser) {
            echo "<p>Username already exists. Please choose a different username.</p>";
        } else {
            // Insert user details into the database
            echo"<p>inserted gng</p>";
            $stmt = $conn->prepare("INSERT INTO registered_users (name, email, username, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $username, $password]);
            echo"<p>inserted</p>";
            // Display success message
            echo "<p>Registration successful. You can now <a href='login.html'>log in</a>.</p>";
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
